<section class="content">
	<div class="container">
		<div class="row">
			
			<div class="col-md-8">
				<div class="big-images">
					<div class="item"><img src="<?= config_item('assets_img') ?>event/1.jpg" alt=""></div>
					<div class="item"><img src="<?= config_item('assets_img') ?>event/2.jpg" alt=""></div>
					<div class="item"><img src="<?= config_item('assets_img') ?>event/3.jpg" alt=""></div>
					<div class="item"><img src="<?= config_item('assets_img') ?>event/4.jpg" alt=""></div>
					<div class="item"><img src="<?= config_item('assets_img') ?>event/5.jpg" alt=""></div>
					<div class="item"><img src="<?= config_item('assets_img') ?>event/6.jpg" alt=""></div>
					<div class="item"><img src="<?= config_item('assets_img') ?>event/7.jpg" alt=""></div>
					<div class="item"><img src="<?= config_item('assets_img') ?>event/8.jpg" alt=""></div>
					<div class="item"><img src="<?= config_item('assets_img') ?>event/9.jpg" alt=""></div>
				</div>
				<br/>
				<div class="thumbs">
					<div class="item"><img src="<?= config_item('assets_img') ?>event/1.jpg" alt=""></div>
					<div class="item"><img src="<?= config_item('assets_img') ?>event/2.jpg" alt=""></div>
					<div class="item"><img src="<?= config_item('assets_img') ?>event/3.jpg" alt=""></div>
					<div class="item"><img src="<?= config_item('assets_img') ?>event/4.jpg" alt=""></div>
					<div class="item"><img src="<?= config_item('assets_img') ?>event/5.jpg" alt=""></div>
					<div class="item"><img src="<?= config_item('assets_img') ?>event/6.jpg" alt=""></div>
					<div class="item"><img src="<?= config_item('assets_img') ?>event/7.jpg" alt=""></div>
					<div class="item"><img src="<?= config_item('assets_img') ?>event/8.jpg" alt=""></div>
					<div class="item"><img src="<?= config_item('assets_img') ?>event/9.jpg" alt=""></div>
				</div>	
			</div>

			
			
			<div class="col-md-4">
				<h3 class="sub-title">Description Photo</h3>
				<p>
					Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer at dolor eu urna tempus commodo. Curabitur hendrerit dui nec leo commodo, a hendrerit odio condimentum. .
				</p>
				<p>
					Aenean ultricies nisl eu nisi hendrerit, at vehicula risus accumsan. Praesent eleifend egestas nisl, vel pharetra nunc dapibus eget
				</p>

				<br>

				<h3 class="sub-title">Photo details</h3>

				<ul class="list-details">
					<li><b>Date</b> : June 08, 2015</li>
					<li><b>Event</b> : Apple Inc</li>
					<li><b>Destination</b> : Branding / Mockup</li>
				</ul>

				<br>

			</div>
		</div>
	</div>
</section>