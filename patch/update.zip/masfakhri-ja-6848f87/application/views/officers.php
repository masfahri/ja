<section>
    <div class="container">
        <div class="title-red" style="margin: 40px 0px ; margin-bottom:60px;">
            <h4 class="bordered">OFFICERS</h4>
        </div>
        <div class="row officers margintop-40" id="work">

            <div class="col-md-4 col-sm-6 work-item">
                <div class="work-detail">
                    <a href="#">
                        <img src="<?= config_item('assets_img') ?>about/1.png" alt="">
                    </a>
                    <div class="text-center col-md-12">
                        <h3>Lorem Ipsum</h3>
                        <p>Lorem Ipsum</p>
                    </div>
                </div>
            </div>

            <div class="col-md-4 col-sm-6 work-item">
                <div class="work-detail">
                    <a href="#">
                        <img src="<?= config_item('assets_img') ?>about/2.png" alt="">
                    </a>
                    <div class="text-center col-md-12">
                        <h3>Lorem Ipsum</h3>
                        <p>Lorem Ipsum</p>
                    </div>
                </div>
            </div>

            <div class="col-md-4 col-sm-6 work-item">
                <div class="work-detail">
                    <a href="#">
                        <img src="<?= config_item('assets_img') ?>about/3.png" alt="">
                    </a>
                    <div class="text-center col-md-12">
                        <h3>Lorem Ipsum</h3>
                        <p>Lorem Ipsum</p>
                    </div>
                </div>
            </div>

            <div class="col-md-4 col-sm-6 work-item">
                <div class="work-detail">
                    <a href="#">
                        <img src="<?= config_item('assets_img') ?>about/3.png" alt="">
                    </a>
                    <div class="text-center col-md-12">
                        <h3>Lorem Ipsum</h3>
                        <p>Lorem Ipsum</p>
                    </div>
                </div>
            </div>

            <div class="col-md-4 col-sm-6 work-item">
                <div class="work-detail">
                    <a href="#">
                        <img src="<?= config_item('assets_img') ?>about/2.png" alt="">
                    </a>
                    <div class="text-center col-md-12">
                        <h3>Lorem Ipsum</h3>
                        <p>Lorem Ipsum</p>
                    </div>
                </div>
            </div>

            <div class="col-md-4 col-sm-6 work-item">
                <div class="work-detail">
                    <a href="#">
                        <img src="<?= config_item('assets_img') ?>about/1.png" alt="">
                    </a>
                    <div class="text-center col-md-12">
                        <h3>Lorem Ipsum</h3>
                        <p>Lorem Ipsum</p>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>