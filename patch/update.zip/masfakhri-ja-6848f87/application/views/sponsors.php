<section>
    <div class="container">
        <div class="title-red" style="margin: 40px 0px ; margin-bottom:60px;">
            <h4 class="bordered">Sponsorship</h4>
        </div>
        <div class="row event margintop-40" id="work" >
            <div class="col-md-4 col-sm-6 work-item">
                <div class="work-detail">

                    <a href="#">
                        <img src="<?= config_item('assets_img') ?>merchants/1.jpg" alt="">
                        <div class="work-info">
                            <div class="centrize">
                                <div class="v-center">
                                    <h3>Delirio Tropical</h3>
                                    <p>Printing, Graphic</p>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 work-item">
                <div class="work-detail">
                    <a href="#">
                        <img src="<?= config_item('assets_img') ?>merchants/2.jpg" alt="">
                        <div class="work-info">
                            <div class="centrize">
                                <div class="v-center">
                                    <h3>Delirio Tropical</h3>
                                    <p>Printing, Graphic</p>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 work-item">
                <div class="work-detail">
                    <a href="#">
                        <img src="<?= config_item('assets_img') ?>merchants/4.jpg" alt="">
                        <div class="work-info">
                            <div class="centrize">
                                <div class="v-center">
                                    <h3>Delirio Tropical</h3>
                                    <p>Printing, Graphic</p>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 work-item">
                <div class="work-detail">
                    <a href="#">
                        <img src="<?= config_item('assets_img') ?>merchants/3.jpg" alt="">
                        <div class="work-info">
                            <div class="centrize">
                                <div class="v-center">
                                    <h3>Delirio Tropical</h3>
                                    <p>Printing, Graphic</p>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 work-item">
                <div class="work-detail">
                    <a href="#">
                        <img src="<?= config_item('assets_img') ?>merchants/5.jpg" alt="">
                        <div class="work-info">
                            <div class="centrize">
                                <div class="v-center">  
                                    <h3>Delirio Tropical</h3>
                                    <p>Printing, Graphic</p>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 work-item">
                <div class="work-detail">
                    <a href="#">
                        <img src="<?= config_item('assets_img') ?>merchants/1.jpg" alt="">
                        <div class="work-info">
                            <div class="centrize">
                                <div class="v-center">
                                    <h3>Delirio Tropical</h3>
                                    <p>Printing, Graphic</p>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>