

<div class="row gallery margintop-40" id="work" >
            <div class="col-md-4 col-sm-6 work-item">
                <div class="work-detail">
                    <a href="portfolio-single-1.html">
                        <img src="<?= config_item('assets_img') ?>portfolio/1.jpg" alt="">
                        <div class="work-info">
                            <div class="centrize">
                                <div class="v-center">
                                    <div class="plus-icon">
                                        <span class="ring"></span>
                                    </div>
                                    <h3>Delirio Tropical</h3>
                                    <p>Printing, Graphic</p>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 work-item">
                <div class="work-detail">
                    <a href="portfolio-single-1.html">
                        <img src="<?= config_item('assets_img') ?>portfolio/2.jpg" alt="">
                        <div class="work-info">
                            <div class="centrize">
                                <div class="v-center">
                                    <div class="plus-icon">
                                        <span class="ring"></span>
                                    </div>
                                    <h3>Delirio Tropical</h3>
                                    <p>Printing, Graphic</p>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 work-item">
                <div class="work-detail">
                    <a href="portfolio-single-1.html">
                        <img src="<?= config_item('assets_img') ?>portfolio/4.jpg" alt="">
                        <div class="work-info">
                            <div class="centrize">
                                <div class="v-center">
                                    <div class="plus-icon">
                                        <span class="ring"></span>
                                    </div>
                                    <h3>Delirio Tropical</h3>
                                    <p>Printing, Graphic</p>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 work-item">
                <div class="work-detail">
                    <a href="portfolio-single-1.html">
                        <img src="<?= config_item('assets_img') ?>portfolio/3.jpg" alt="">
                        <div class="work-info">
                            <div class="centrize">
                                <div class="v-center">
                                    <div class="plus-icon">
                                        <span class="ring"></span>
                                    </div>
                                    <h3>Delirio Tropical</h3>
                                    <p>Printing, Graphic</p>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 work-item">
                <div class="work-detail">
                    <a href="portfolio-single-1.html">
                        <img src="<?= config_item('assets_img') ?>portfolio/5.jpg" alt="">
                        <div class="work-info">
                            <div class="centrize">
                                <div class="v-center">
                                    <div class="plus-icon">
                                        <span class="ring"></span>
                                    </div>
                                    <h3>Delirio Tropical</h3>
                                    <p>Printing, Graphic</p>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 work-item">
                <div class="work-detail">
                    <a href="portfolio-single-1.html">
                        <img src="<?= config_item('assets_img') ?>portfolio/1.jpg" alt="">
                        <div class="work-info">
                            <div class="centrize">
                                <div class="v-center">
                                    <div class="plus-icon">
                                        <span class="ring"></span>
                                    </div>
                                    <h3>Delirio Tropical</h3>
                                    <p>Printing, Graphic</p>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
